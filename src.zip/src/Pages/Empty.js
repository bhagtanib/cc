import React from "react";
import "../Styles/Empty.css";

const Empty = () => {
  return <div className="empty-container"></div>;
};

export default Empty;
